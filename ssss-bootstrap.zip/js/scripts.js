$(function() {
    $("#testBtn").click(function(){
        $("#testModal").modal("show");
    });
});